package com.cognizant.menu.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

//@ResponseStatus(value = HttpStatus.BAD_GATEWAY, reason = "menu Is Missing....")
public class MenuNotFoundException extends RuntimeException {

}
