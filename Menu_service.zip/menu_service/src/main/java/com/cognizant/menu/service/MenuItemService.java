package com.cognizant.menu.service; 

import java.util.List;

import javax.validation.Valid;

import com.cognizant.menu.model.MenuItem;

public interface MenuItemService {

	public List<MenuItem> getMenuItems();
	public MenuItem getMenuById( Long id);
	public MenuItem addItem( @Valid MenuItem item);
	public String deleteItem(Long id);

}
