package com.cognizant.menu.controller;

import java.util.List;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.menu.model.MenuItem;
import com.cognizant.menu.service.MenuItemService;
import com.cognizant.menu.service.MenuitemserviceImpl;

@RestController
@RequestMapping(value = "/menu")
@Validated
public class MenuController {
	@Autowired
	MenuItemService menuItemService;


	@GetMapping(value = "/getbyid/{id}")
	public ResponseEntity<MenuItem> getMenuId(@PathVariable("id") Long id) {

		MenuItem menuItem = menuItemService.getMenuById(id);
		return new ResponseEntity<MenuItem>(menuItem, HttpStatus.OK);

	}

	@PostMapping(value = "/save")
	public ResponseEntity<MenuItem> addmenuItem(@Valid @RequestBody MenuItem item) {

		
			MenuItem menuItem = menuItemService.addItem(item);
			return new ResponseEntity<MenuItem>(menuItem, HttpStatus.OK);
		

	}

	@DeleteMapping(value = "/delete/{id}")
	public ResponseEntity<String> deletemenuItem(@PathVariable("id") Long id) {

		
			String menuItem = menuItemService.deleteItem(id);
			return new ResponseEntity<String>(menuItem, HttpStatus.OK);
		

	}

	@GetMapping(value = "/getallmenu")
	public ResponseEntity<List<MenuItem>> getAll() {

		
			List<MenuItem> mlistItems = menuItemService.getMenuItems();
			return new ResponseEntity<List<MenuItem>>(mlistItems, HttpStatus.OK);
		

	}

}
