package com.cognizant.menu.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.menu.exception.MenuNotFoundException;
import com.cognizant.menu.model.MenuItem;
import com.cognizant.menu.repo.MenuitemRepo;


@Service
@Transactional
public class MenuitemserviceImpl implements MenuItemService {
	@Autowired
	MenuitemRepo menurepo;

	

	@Override
	public MenuItem getMenuById(Long id) {
		// TODO Auto-generated method stub
		
			Optional<MenuItem> mOptional = menurepo.findById(id);
			if (mOptional.isPresent()) {
				mOptional = menurepo.findById(id);
				return mOptional.get();
			}
			throw new MenuNotFoundException();

		
	}

	public MenuItem addItem(@Valid MenuItem item) {
		// TODO Auto-generated method stub
		
			MenuItem menuItem = menurepo.save(item);
			return menuItem;
		

	}

	public List<MenuItem> getMenuItems() {
		// TODO Auto-generated method stub
		
			return menurepo.findAll();
		
	}

	public String deleteItem(Long id) {

		menurepo.deleteById(id);
		return "deleted sucessfully";
	}



	

}
