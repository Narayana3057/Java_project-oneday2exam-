package com.cognizant.menu.model;

import java.util.Date;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.sun.istack.NotNull;

@Entity
public class MenuItem {
	MenuItem(){
		
	}
	@NotNull
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@NotBlank
	@Size(min = 4, max = 20)
	private String name;
	@NotNull
	@Min(value=10)
	private float price;
	public MenuItem(Long id, @NotBlank @Size(min = 4, max = 20) String name, @Min(10) float price, boolean active,
			Date dateOfLaunch, @NotBlank @Size(min = 4, max = 20) String category, boolean freeDeliver) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.active = active;
		this.dateOfLaunch = dateOfLaunch;
		this.category = category;
		this.freeDeliver = freeDeliver;
	}

	private boolean active;
	private Date dateOfLaunch;
	@NotBlank
	@Size(min = 4, max = 20)
	private String category;
	
	private boolean freeDeliver;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Date getDateOfLaunch() {
		return dateOfLaunch;
	}

	public void setDateOfLaunch(Date dateOfLaunch) {
		this.dateOfLaunch = dateOfLaunch;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public boolean isFreeDeliver() {
		return freeDeliver;
	}

	public void setFreeDeliver(boolean freeDeliver) {
		this.freeDeliver = freeDeliver;
	}

}
