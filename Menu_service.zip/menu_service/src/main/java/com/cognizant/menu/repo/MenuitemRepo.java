package com.cognizant.menu.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.menu.model.MenuItem;
@Repository
public interface MenuitemRepo extends JpaRepository<MenuItem,java.lang.Long>{
	

}
